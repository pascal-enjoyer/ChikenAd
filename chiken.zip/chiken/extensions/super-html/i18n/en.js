"use strict";
module.exports = {
    description: "A blank extension",
    open_panel: "super html",
};