# QA

### ERROR

***

Q : TypeError: Br is not a function

A : 合并成`super.html` 后，不支持`wasm` 3D物理引擎的 `Bullet （ammo.js）`有 `wasm` 版本

- 选择其它3D物理引擎

<br/>

